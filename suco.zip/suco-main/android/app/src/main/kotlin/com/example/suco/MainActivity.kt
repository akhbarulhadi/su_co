package com.example.suco

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

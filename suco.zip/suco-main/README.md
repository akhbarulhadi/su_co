<a><p align="center"><img src="https://github.com/akhbarulhadi/suco/blob/main/lib/assets/icon_suco.png" width="150" alt="Laravel Logo"></a></p>

<p style="font-size: 20px;" align="center">
SUCO
</p>

## Information

Aplikasi Suplai Controller Ini (SUCO) adalah sebuah aplikasi yang bertujuan untuk memudahkan proses suplai barang dari produksi ke gudang.

Keuntungan menggunakan aplikasi suplai controller (SUCO) adalah memudahkan Pengguna dalam melihat jumlah barang yang tersedia, barang yang berhasil di produksi harga satuan, Dll.


## License

PBL_SUCO

## Cara pakai Git

git init,
git add nama_file/*,
git commit -m "percobaan" (untuk comment/deskripsi),
git push -u origin (untuk dorong file dari directory lokal laptop ke repository github),
git pull origin main (untuk ambil dari repo github ke directory lokal).

## untuk ambil repo github ke lokal directory:

1.git clone link github
2.setelah itu composer install/composer update
3.env.example copas dan jadikan .env
4.php artisan key:generate
5.php artisan migrate
6.php artisan serve